package View;

import java.awt.*;

public class GUIconstants {
    public static Color white = Color.white;
    public static Color black = Color.black;
    public static Color blue = Color.decode("#3E2F84");
    public static Color textFieldHint = Color.decode("#959595");
    public static Color background = Color.decode("#F5F5F5");

}
